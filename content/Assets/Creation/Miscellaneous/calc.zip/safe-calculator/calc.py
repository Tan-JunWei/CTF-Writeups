import math
import os

def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    try:
        return x / y
    except ZeroDivisionError:
        return "Error: Cannot divide by zero!"

def power(x, y):
    return x ** y

def modulo(x, y):
    try:
        return x % y
    except ZeroDivisionError:
        return "Error: Cannot divide by zero for modulo!"

def square_root(x):
    if x < 0:
        return "Error: Cannot calculate the square root of a negative number!"
    return math.sqrt(x)

operations = {
    '+': add,
    '-': subtract,
    '*': multiply,
    '/': divide,
    '^': power,
    '%': modulo,
    'sqrt': square_root
}

def main():
    print("Welcome to the Interactive Basic Calculator!")
    print("Available operations:")
    print("  Binary: +, -, *, /, ^ (power), % (modulo)")
    print("  Unary: sqrt (square root)")
    print("  Commands: q (quit), c (clear), h (help)")
    print("-" * 30)

    while True:
        operation = input("Enter operation: ")

        if operation.lower() == 'q':
            print("Thank you for using the calculator. Goodbye!")
            break
        
        if operation.lower() == 'c':
            os.system('cls' if os.name == 'nt' else 'clear')
            print("Console cleared.")
            continue

        if operation.lower() == 'h':
            print("Available operations:")
            print("  Binary: +, -, *, /, ^ (power), % (modulo)")
            print("  Unary: sqrt (square root)")
            print("  Commands: q (quit), c (clear), h (help)")
            print("-" * 30)
            continue

        if operation not in operations:
            print("Invalid operation choice.")
            continue

        result = None

        if operation == 'sqrt':
            try:
                num1 = float(input("Enter number: "))
                result = operations[operation](num1)
            except ValueError:
                print("Invalid input. Please enter a valid number.")
                continue
        
        else:
            try:
                num1 = float(input("Enter first number: "))
                num2 = float(input("Enter second number: "))
                result = operations[operation](num1, num2)
            except ValueError:
                print("Invalid input. Please enter valid numbers.")
                continue

        if result is not None:
            print(f"Result: {result}\n")

if __name__ == "__main__":
    main()
